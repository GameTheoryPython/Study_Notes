import matplotlib.pyplot as plt

plt.subplot(121)
plt.plot(range(12))

plt.subplot(122)
plt.plot([3,2,1],[1,2,3])

plt.show()